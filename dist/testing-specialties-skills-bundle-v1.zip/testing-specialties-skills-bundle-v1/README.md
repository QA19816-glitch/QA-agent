# 测试专项 Skills 分类包

- Source repository: https://github.com/QA19816-glitch/QA-agent
- Source doc: https://github.com/QA19816-glitch/QA-agent/blob/main/inventory/SOFTWARE_TESTING_SPECIALTIES.md
- Included skills: **93**

## Included skills

- qa-prd-analyzer -> skills/qa-prd-analyzer
- qa-test-point-extractor -> skills/qa-test-point-extractor
- qa-testcase-writer -> skills/qa-testcase-writer
- qa-traceability-mapper -> skills/qa-traceability-mapper
- qa-test-data-factory -> skills/qa-test-data-factory
- qa-test-report-generator -> skills/qa-test-report-generator
- qa-regression-planner -> skills/qa-regression-planner
- qa-release-gate-checker -> skills/qa-release-gate-checker
- qa -> skills/gstack-qa
- qa-browser-tester -> skills/qa-browser-tester
- qa-patrol -> skills/qa-patrol
- Test Generator -> skills/test-generator
- test-master -> skills/test-master
- test-patterns -> skills/test-patterns
- test-sentinel -> skills/test-sentinel
- ux-qa-gate -> skills/ux-qa-gate
- qa-api-runner -> skills/qa-api-runner
- APITester Agent-Driven API Testing -> skills/openclaw-api-tester
- API Mock Server Generator -> skills/sovereign-api-mock-generator
- openapi-spec -> skills/openapi-spec
- Postman -> skills/Postman
- qa-web-e2e-runner -> skills/qa-web-e2e-runner
- e2e-test-orchestrator -> skills/e2e-test-orchestrator
- e2e-testing -> skills/e2e-testing
- e2e-testing-patterns -> skills/e2e-testing-patterns
- playwright-browser-automation -> skills/playwright-browser-automation
- playwright-cli -> skills/playwright-cli-openclaw
- playwright-mcp -> skills/playwright-mcp
- playwright-npx -> skills/playwright-npx
- playwright-pro -> skills/playwright-pro
- playwright-skill -> skills/playwright-skill
- web-screenshot -> skills/web-screenshot
- mobile-appium-test -> skills/mobile-appium-test
- android-automation -> skills/android-adb
- android-device-automation -> skills/midscene-android-automation
- mobile-responsive -> skills/mobile-responsive
- fastlane -> skills/fastlane
- TestFlight -> skills/TestFlight
- api-performance-testing -> skills/api-performance-testing
- frontend-performance-audit -> skills/frontend-performance-audit
- webperf-core-web-vitals -> skills/webperf-core-web-vitals
- Chrome DevTools Auto Analyzer -> skills/web-auto-analyzer
- performance-tuning -> skills/performance-tuning
- seo-optimizer -> skills/seo-optimizer
- seo-analyzer -> skills/shelly-seo-analyzer
- website-seo -> skills/website-seo
- security-audit -> skills/security-audit-toolkit
- security-auditor -> skills/security-auditor
- security-scanner -> skills/security-scanner
- add-analytics -> skills/add-analytics
- analytics-tracking -> skills/analytics-tracking-2
- check-analytics -> skills/check-analytics
- sensors-analytics-tracking -> skills/sensors-analytics-tracking
- qa-bug-triage -> skills/qa-bug-triage
- bug-investigation -> skills/bug-investigation
- jira -> skills/jira
- linear -> skills/linear
- incident-fupan -> skills/incident-fupan
- db-readonly -> skills/db-readonly
- sql-toolkit -> skills/sql-toolkit
- postgres -> skills/postgres-mcp-skill
- grafana -> skills/grafana-api
- grafana-lens -> skills/grafana-lens
- kibana -> skills/kibana
- prometheus -> skills/prometheus
- promql-cli -> skills/promql-cli
- log-analyzer -> skills/openclaw-log-analyzer
- logging-observability -> skills/logging-observability
- tcpdump -> skills/tcpdump
- Wireshark Network Traffic Analysis -> skills/wireshark-analysis
- docker -> skills/docker-skill
- Docker Compose -> skills/docker-compose
- Docker Pro Diagnostic -> skills/docker-diag
- kubectl-skill -> skills/kubectl
- Kubernetes -> skills/k8s
- kubernetes-devops -> skills/kubernetes-devops
- helm -> skills/helm
- kafka -> skills/kafka
- mqtt-client -> skills/mqtt-client
- rabbitmq-client-guide -> skills/rabbitmq-client-guide
- Nginx -> skills/Nginx
- Traefik -> skills/Traefik
- initial-traefik -> skills/initial-traefik
- aws-infra -> skills/aws-infra
- cloudflare -> skills/cloudflare-api
- cloudflare-tunnel -> skills/cloudflare-tunnel-manager
- terraform-iac -> skills/terraform-iac
- GitHub Actions -> skills/github-actions
- GitLab -> skills/GitLab
- Jenkins -> skills/Jenkins
- CI-CD -> skills/CI-CD
- cicd-pipeline -> skills/cicd-pipeline
- Monitoring -> skills/Monitoring

## Usage

1. Unzip this package
2. Copy the included `skills/` subfolders into your OpenClaw workspace `skills/` directory
3. Start a new session or restart gateway so the skills are loaded
