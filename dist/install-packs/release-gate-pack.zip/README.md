# release-gate-pack

Included skills:
- qa-bug-triage
- incident-fupan
- qa-release-gate-checker
- qa-regression-planner
- qa-traceability-mapper

Usage:
1. unzip this package
2. copy the included `skills/` folders into your OpenClaw workspace `skills/` directory
