# feishu-docs-content-pack

Included skills:
- feishu-doc
- feishu-drive
- feishu-perm
- feishu-wiki
- summarize
- pdf-skill
- html-to-pdf
- pptx-generator
- openclaw-slides
- image-handler
