# qa-core-pack

Included skills:
- qa-prd-analyzer
- qa-test-point-extractor
- qa-testcase-writer
- qa-api-runner
- qa-browser-tester
- qa-web-e2e-runner
- qa-bug-triage
- qa-regression-planner
- qa-release-gate-checker
- qa-test-report-generator

Usage:
1. unzip this package
2. copy the included `skills/` folders into your OpenClaw workspace `skills/` directory
