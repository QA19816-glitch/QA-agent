# api-testing-pack

Included skills:
- qa-api-runner
- openclaw-api-tester
- api-performance-testing
- postman
- openapi-spec

Usage:
1. unzip this package
2. copy the included `skills/` folders into your OpenClaw workspace `skills/` directory
