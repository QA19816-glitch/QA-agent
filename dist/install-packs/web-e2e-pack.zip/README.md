# web-e2e-pack

Included skills:
- qa-web-e2e-runner
- qa-browser-tester
- playwright-pro
- playwright-cli-openclaw
- visual-regression-testing

Usage:
1. unzip this package
2. copy the included `skills/` folders into your OpenClaw workspace `skills/` directory
