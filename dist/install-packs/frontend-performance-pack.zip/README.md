# frontend-performance-pack

Included skills:
- frontend-performance
- frontend-performance-audit
- react-performance
- webperf-core-web-vitals
- web-perf
- webperf-loading
- webperf-interaction
- webperf-media
- web-auto-analyzer
- performance-profiler

Usage:
1. unzip this package
2. copy the included `skills/` folders into your OpenClaw workspace `skills/` directory
