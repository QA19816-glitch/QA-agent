# mobile-testing-pack

Included skills:
- mobile-appium-test
- android-adb
- ios-simulator
- testflight
- node-connect

Usage:
1. unzip this package
2. copy the included `skills/` folders into your OpenClaw workspace `skills/` directory
