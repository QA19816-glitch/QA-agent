# productivity-office-pack

Included skills:
- automate-excel
- excel-xlsx
- weather
- tmux
- 1password
- obsidian
- notion
- trello
- gog
- session-logs
