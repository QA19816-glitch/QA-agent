全量技能包

共 248 个 skills。
解压后将 skills/ 目录复制到 OpenClaw workspace 的 skills/ 目录即可。
