# essential-setup-skills-bundle-v1.zip

Included skills:
- find-skills-3
- summarize
- skill-vetter
- feishu-doc
- feishu-wiki
- daily-report-writer
- weekly-report-writer
- github
- coding-agent-common
- skill-creator
- deerflow-super-agent-harness
