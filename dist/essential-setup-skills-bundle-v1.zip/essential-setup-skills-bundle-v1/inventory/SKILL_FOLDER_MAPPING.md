# Display Name -> Repository Folder Mapping

- **find-skills** -> `skills/find-skills-3`
- **summarize** -> `skills/summarize`
- **agent-browser** -> `skills/openclaw-agent-browser`
- **skill-vetter** -> `skills/skill-vetter`
- **feishu-doc** -> `skills/feishu-doc`
- **feishu-wiki** -> `skills/feishu-wiki`
- **daily-report-writer** -> `skills/daily-report-writer`
- **weekly-report-writer** -> `skills/weekly-report-writer`
- **github** -> `skills/github`
- **coding-agent** -> `skills/coding-agent-common`
- **skill-creator** -> `skills/skill-creator`
- **deerflow-super-agent-harness** -> `skills/deerflow-super-agent-harness`
