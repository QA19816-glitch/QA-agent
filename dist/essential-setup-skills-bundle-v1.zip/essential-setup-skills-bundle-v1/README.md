# 建议安装 Skills 分类包

- Source repository: https://github.com/QA19816-glitch/QA-agent
- Source doc: https://github.com/QA19816-glitch/QA-agent/blob/main/inventory/ESSENTIAL_SETUP_SKILLS.md
- Included skills: **12**

## Included skills

- find-skills -> skills/find-skills-3
- summarize -> skills/summarize
- agent-browser -> skills/openclaw-agent-browser
- skill-vetter -> skills/skill-vetter
- feishu-doc -> skills/feishu-doc
- feishu-wiki -> skills/feishu-wiki
- daily-report-writer -> skills/daily-report-writer
- weekly-report-writer -> skills/weekly-report-writer
- github -> skills/github
- coding-agent -> skills/coding-agent-common
- skill-creator -> skills/skill-creator
- deerflow-super-agent-harness -> skills/deerflow-super-agent-harness

## Usage

1. Unzip this package
2. Copy the included `skills/` subfolders into your OpenClaw workspace `skills/` directory
3. Start a new session or restart gateway so the skills are loaded
